//
//  UIAlert.h
//  UIKit
//
//  Copyright (c) 2005-2011, Apple Inc. All rights reserved.
//

#import <UIKit/UIActionSheet.h>
#import <UIKit/UIAlertView.h>

