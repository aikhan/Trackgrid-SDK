//
//  UINibDeclarations.h
//  UIKit
//
//  Copyright (c) 2005-2011, Apple Inc. All rights reserved.
//

#ifndef IBOutlet
#define IBOutlet
#endif

#ifndef IBOutletCollection
#define IBOutletCollection(ClassName)
#endif

#ifndef IBAction
#define IBAction void
#endif
